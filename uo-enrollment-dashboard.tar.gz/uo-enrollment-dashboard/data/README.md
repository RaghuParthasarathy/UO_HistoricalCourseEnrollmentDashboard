# Data files

The Streamlit app reads two files from this directory:

- `enrollment.parquet` — built by `python prepare_data.py` from `combined.csv`
- `catalog.csv` — copied by `prepare_data.py` from the catalog scraper output

**Both files must be committed to GitHub** for Streamlit Cloud to see them.
Run `prepare_data.py` locally, then `git add data/ && git commit && git push`.
